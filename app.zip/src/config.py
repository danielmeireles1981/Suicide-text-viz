from pathlib import Path
DATA = Path("data")
RAW = DATA / "raw"
INTERIM = DATA / "interim"
PROCESSED = DATA / "processed"
REPORTS = Path("reports")
FIGS = REPORTS / "figures"
