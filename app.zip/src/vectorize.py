# espaço para funções de vetorização extra (ex.: char-ngrams, embeddings, etc.)
